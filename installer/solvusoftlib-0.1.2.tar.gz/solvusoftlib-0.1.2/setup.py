# coding=gbk

from setuptools import setup, find_packages

with open("README.md", "r", encoding='utf-8') as fh:
    long_description = fh.read()


setup(
    name='solvusoftlib',
    version="0.1.2",
    description=(
        'Multi-process secure logs both in linux and windows'
    ),
    long_description=open('README.md', 'r').read(),
    long_description_content_type="text/markdown",
    author='Xie Zheyuan',
    author_email='billy03282@163.com',

    packages=['solvusoftlib'],

    platforms=["all"],
    url='https://github.com/XieZheyuan/solvusoftlib',   # ��������ӣ�һ��дgithub�Ϳ����ˣ����pypi��ת������ȥ
    classifiers=[
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6',
        'Topic :: Software Development :: Libraries',
        'License :: OSI APPROVED :: APACHE SOFTWARE LICENSE'.capitalize(),
        'TOPIC :: INTERNET :: WWW/HTTP',
        'TOPIC :: INTERNET',
        'TOPIC :: SCIENTIFIC/ENGINEERING :: INFORMATION ANALYSIS',
        'TOPIC :: SOFTWARE DEVELOPMENT :: LIBRARIES :: PYTHON MODULES'
    ],
    install_requires=[
        'requests',
        'BeautifulSoup'
    ]
)